import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { CoinPackage, AppScreenshot } from '../types';
import { 
  Sliders, 
  Coins, 
  Plus, 
  Trash2, 
  Edit3, 
  TrendingUp, 
  Percent, 
  RefreshCw, 
  CheckCircle2, 
  Image as ImageIcon, 
  Globe, 
  Phone, 
  MessageCircle, 
  Mail, 
  ShieldCheck, 
  Sparkles, 
  DollarSign, 
  Save, 
  Eye, 
  X,
  Layers,
  ArrowRight
} from 'lucide-react';

export const SiteEditorView: React.FC = () => {
  const { 
    coinPackages, 
    addCoinPackage, 
    updateCoinPackage, 
    deleteCoinPackage, 
    bulkAdjustCoinPrices, 
    resetCoinPackages,
    screenshots,
    addAppScreenshot,
    updateAppScreenshot,
    deleteAppScreenshot,
    resetAppScreenshots,
    appConfig,
    updateAppConfig
  } = useApp();

  const [activeSubTab, setActiveSubTab] = useState<'coins' | 'branding' | 'contacts' | 'screenshots'>('coins');
  const [successMessage, setSuccessMessage] = useState<string>('');

  // Branding Form State
  const [appName, setAppName] = useState(appConfig.appName || '');
  const [appSlogan, setAppSlogan] = useState(appConfig.appSlogan || '');
  const [heroDescription, setHeroDescription] = useState(appConfig.heroDescription || '');
  const [tickerText, setTickerText] = useState(appConfig.tickerText || '');
  const [officialBadge, setOfficialBadge] = useState(appConfig.officialBadge || '');
  const [appLogo, setAppLogo] = useState(appConfig.appLogo || '');

  // Contact Form State
  const [supportWhatsApp, setSupportWhatsApp] = useState(appConfig.supportWhatsApp || '');
  const [supportTelegram, setSupportTelegram] = useState(appConfig.supportTelegram || '');
  const [supportEmail, setSupportEmail] = useState(appConfig.supportEmail || '');

  // Bulk Coin Price Adjust State
  const [bulkPercent, setBulkPercent] = useState<number>(10);
  const [bulkCurrency, setBulkCurrency] = useState<'all' | 'PKR' | 'USD' | 'INR'>('all');

  // Add/Edit Package Modal State
  const [isPackageModalOpen, setIsPackageModalOpen] = useState(false);
  const [editingPackageId, setEditingPackageId] = useState<string | null>(null);
  const [pkgCoins, setPkgCoins] = useState<number>(100000);
  const [pkgBonus, setPkgBonus] = useState<number>(10000);
  const [pkgPricePKR, setPkgPricePKR] = useState<number>(3500);
  const [pkgPriceUSD, setPkgPriceUSD] = useState<number>(12);
  const [pkgPriceINR, setPkgPriceINR] = useState<number>(1000);
  const [pkgBadge, setPkgBadge] = useState<string>('VIP Choice');

  // Add Screenshot Modal State
  const [isScreenshotModalOpen, setIsScreenshotModalOpen] = useState(false);
  const [editingScreenshotId, setEditingScreenshotId] = useState<string | null>(null);
  const [screenSrc, setScreenSrc] = useState('');
  const [screenTitle, setScreenTitle] = useState('');
  const [screenCategory, setScreenCategory] = useState('Voice Rooms');
  const [screenBadge, setScreenBadge] = useState('⭐ Official UI');

  const showNotification = (msg: string) => {
    setSuccessMessage(msg);
    setTimeout(() => setSuccessMessage(''), 3000);
  };

  const handleSaveBranding = (e: React.FormEvent) => {
    e.preventDefault();
    updateAppConfig({
      appName: appName.trim() || appConfig.appName,
      appSlogan: appSlogan.trim(),
      heroDescription: heroDescription.trim(),
      tickerText: tickerText.trim(),
      officialBadge: officialBadge.trim(),
      appLogo: appLogo.trim() || appConfig.appLogo
    });
    showNotification('Website identity, title & announcements updated live across the entire website!');
  };

  const handleSaveContacts = (e: React.FormEvent) => {
    e.preventDefault();
    updateAppConfig({
      supportWhatsApp: supportWhatsApp.trim(),
      supportTelegram: supportTelegram.trim(),
      supportEmail: supportEmail.trim()
    });
    showNotification('Official support channels & contact numbers updated live!');
  };

  const handleBulkPriceAdjust = (direction: 'increase' | 'decrease') => {
    const percent = direction === 'increase' ? Math.abs(bulkPercent) : -Math.abs(bulkPercent);
    bulkAdjustCoinPrices(percent, bulkCurrency);
    showNotification(`Coin prices successfully ${direction === 'increase' ? 'increased' : 'discounted'} by ${Math.abs(bulkPercent)}% for ${bulkCurrency.toUpperCase()}!`);
  };

  const openAddPackageModal = () => {
    setEditingPackageId(null);
    setPkgCoins(100000);
    setPkgBonus(10000);
    setPkgPricePKR(3500);
    setPkgPriceUSD(12);
    setPkgPriceINR(1000);
    setPkgBadge('Hot Bundle');
    setIsPackageModalOpen(true);
  };

  const openEditPackageModal = (pkg: CoinPackage) => {
    setEditingPackageId(pkg.id);
    setPkgCoins(pkg.coins);
    setPkgBonus(pkg.bonusCoins);
    setPkgPricePKR(pkg.pricePKR);
    setPkgPriceUSD(pkg.priceUSD);
    setPkgPriceINR(pkg.priceINR);
    setPkgBadge(pkg.badge || '');
    setIsPackageModalOpen(true);
  };

  const handleSavePackage = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingPackageId) {
      updateCoinPackage(editingPackageId, {
        coins: Number(pkgCoins),
        bonusCoins: Number(pkgBonus),
        pricePKR: Number(pkgPricePKR),
        priceUSD: Number(pkgPriceUSD),
        priceINR: Number(pkgPriceINR),
        badge: pkgBadge.trim() || undefined
      });
      showNotification('Coin package updated successfully!');
    } else {
      addCoinPackage({
        coins: Number(pkgCoins),
        bonusCoins: Number(pkgBonus),
        pricePKR: Number(pkgPricePKR),
        priceUSD: Number(pkgPriceUSD),
        priceINR: Number(pkgPriceINR),
        badge: pkgBadge.trim() || undefined
      });
      showNotification('New coin package added to store!');
    }
    setIsPackageModalOpen(false);
  };

  const openAddScreenshotModal = () => {
    setEditingScreenshotId(null);
    setScreenSrc('');
    setScreenTitle('');
    setScreenCategory('Voice Rooms');
    setScreenBadge('⭐ Official UI');
    setIsScreenshotModalOpen(true);
  };

  const openEditScreenshotModal = (shot: AppScreenshot) => {
    setEditingScreenshotId(shot.id);
    setScreenSrc(shot.src);
    setScreenTitle(shot.title);
    setScreenCategory(shot.category);
    setScreenBadge(shot.badge);
    setIsScreenshotModalOpen(true);
  };

  const handleSaveScreenshot = (e: React.FormEvent) => {
    e.preventDefault();
    if (!screenSrc.trim() || !screenTitle.trim()) return;

    if (editingScreenshotId) {
      updateAppScreenshot(editingScreenshotId, {
        src: screenSrc.trim(),
        title: screenTitle.trim(),
        category: screenCategory.trim(),
        badge: screenBadge.trim()
      });
      showNotification('Showcase screenshot updated!');
    } else {
      addAppScreenshot({
        src: screenSrc.trim(),
        title: screenTitle.trim(),
        category: screenCategory.trim(),
        badge: screenBadge.trim()
      });
      showNotification('New screenshot added to showcase slider & marquee!');
    }
    setIsScreenshotModalOpen(false);
  };

  return (
    <div className="space-y-8 animate-fadeIn pb-12 max-w-7xl mx-auto">
      {/* Top Banner / Hero */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-purple-950 via-slate-900 to-indigo-950 border border-purple-800/50 p-6 sm:p-8 shadow-2xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="px-3 py-1 rounded-full text-xs font-black uppercase bg-pink-500/20 text-pink-300 border border-pink-500/40 flex items-center gap-1.5">
                <Sliders className="w-3.5 h-3.5" />
                Master Site & Pricing Editor
              </span>
              <span className="px-3 py-1 rounded-full text-xs font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" />
                Live Instant Sync Active
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl md:text-4xl font-black text-white">
              Full Website Customizer & Coin Price Manager
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 max-w-2xl leading-relaxed">
              Complete owner control center: Increase or decrease coin prices, add new packages, customize the website name, announcements, contacts, and showcase media in real-time.
            </p>
          </div>

          <div className="shrink-0 bg-slate-900/90 border border-purple-500/40 rounded-2xl p-4 flex flex-col items-center justify-center text-center shadow-xl">
            <div className="text-xs font-bold text-amber-300 uppercase tracking-wider mb-0.5">
              Current Coin Packages
            </div>
            <div className="text-3xl font-black text-white font-mono">
              {coinPackages.length} Active
            </div>
            <div className="text-[11px] text-slate-400 mt-1">
              {screenshots.length} Showcase Screens
            </div>
          </div>
        </div>

        {/* Success Alert */}
        {successMessage && (
          <div className="mt-4 p-3 rounded-2xl bg-emerald-950/80 border border-emerald-500/50 text-emerald-300 text-xs font-semibold flex items-center gap-2 animate-fadeIn shadow-lg">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{successMessage}</span>
          </div>
        )}

        {/* Sub-tab Navigation */}
        <div className="flex items-center gap-2 mt-6 pt-6 border-t border-slate-800/80 overflow-x-auto pb-1">
          <button
            onClick={() => setActiveSubTab('coins')}
            className={`px-4 py-2.5 rounded-xl text-xs font-bold flex items-center gap-2 transition cursor-pointer whitespace-nowrap ${
              activeSubTab === 'coins'
                ? 'bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 shadow-lg shadow-amber-950'
                : 'bg-slate-900/80 text-slate-300 hover:text-white border border-slate-800 hover:border-slate-700'
            }`}
          >
            <Coins className="w-4 h-4" />
            <span>Coin Pricing & Packages ({coinPackages.length})</span>
          </button>

          <button
            onClick={() => setActiveSubTab('branding')}
            className={`px-4 py-2.5 rounded-xl text-xs font-bold flex items-center gap-2 transition cursor-pointer whitespace-nowrap ${
              activeSubTab === 'branding'
                ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-lg shadow-purple-950'
                : 'bg-slate-900/80 text-slate-300 hover:text-white border border-slate-800 hover:border-slate-700'
            }`}
          >
            <Globe className="w-4 h-4" />
            <span>Website Identity & Title</span>
          </button>

          <button
            onClick={() => setActiveSubTab('contacts')}
            className={`px-4 py-2.5 rounded-xl text-xs font-bold flex items-center gap-2 transition cursor-pointer whitespace-nowrap ${
              activeSubTab === 'contacts'
                ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-lg shadow-emerald-950'
                : 'bg-slate-900/80 text-slate-300 hover:text-white border border-slate-800 hover:border-slate-700'
            }`}
          >
            <Phone className="w-4 h-4" />
            <span>Support & WhatsApp Contacts</span>
          </button>

          <button
            onClick={() => setActiveSubTab('screenshots')}
            className={`px-4 py-2.5 rounded-xl text-xs font-bold flex items-center gap-2 transition cursor-pointer whitespace-nowrap ${
              activeSubTab === 'screenshots'
                ? 'bg-gradient-to-r from-pink-600 to-rose-600 text-white shadow-lg shadow-pink-950'
                : 'bg-slate-900/80 text-slate-300 hover:text-white border border-slate-800 hover:border-slate-700'
            }`}
          >
            <ImageIcon className="w-4 h-4" />
            <span>Showcase Screens ({screenshots.length})</span>
          </button>
        </div>
      </div>

      {/* SUB-TAB 1: COIN PRICING & PACKAGE MANAGER */}
      {activeSubTab === 'coins' && (
        <div className="space-y-6">
          {/* Bulk Pricing Quick Adjuster */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 sm:p-7 shadow-xl space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-amber-400" />
                  Quick Price Increase & Discount Controller
                </h3>
                <p className="text-xs text-slate-400">
                  Easily increase coin rates by percentage (e.g. +10%, +25%) or apply bulk discounts across all packages
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={resetCoinPackages}
                  className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition cursor-pointer flex items-center gap-1.5"
                  title="Reset to default official rates"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Reset Default Prices</span>
                </button>
                <button
                  type="button"
                  onClick={openAddPackageModal}
                  className="px-4 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-black transition cursor-pointer flex items-center gap-1.5 shadow"
                >
                  <Plus className="w-4 h-4" />
                  <span>+ Add New Package</span>
                </button>
              </div>
            </div>

            {/* Quick Presets Bar */}
            <div className="flex flex-wrap items-center gap-3 pt-2">
              <div className="flex items-center gap-2 bg-slate-950 border border-slate-800 rounded-xl px-3 py-1.5">
                <span className="text-xs text-slate-400">Currency:</span>
                <select
                  value={bulkCurrency}
                  onChange={(e) => setBulkCurrency(e.target.value as any)}
                  className="bg-transparent text-xs text-white font-bold focus:outline-none cursor-pointer"
                >
                  <option value="all">All (PKR, USD, INR)</option>
                  <option value="PKR">PKR Only</option>
                  <option value="USD">USD Only</option>
                  <option value="INR">INR Only</option>
                </select>
              </div>

              <div className="flex items-center gap-2 bg-slate-950 border border-slate-800 rounded-xl px-3 py-1.5">
                <span className="text-xs text-slate-400">Percentage:</span>
                <input
                  type="number"
                  min="1"
                  max="500"
                  value={bulkPercent}
                  onChange={(e) => setBulkPercent(Math.max(1, parseInt(e.target.value) || 1))}
                  className="w-16 bg-transparent text-xs text-amber-300 font-bold focus:outline-none"
                />
                <span className="text-xs text-slate-400">%</span>
              </div>

              <button
                type="button"
                onClick={() => handleBulkPriceAdjust('increase')}
                className="px-4 py-2 rounded-xl bg-rose-900/60 hover:bg-rose-800 text-rose-200 border border-rose-700/60 text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shadow"
              >
                <TrendingUp className="w-3.5 h-3.5" />
                <span>Increase Prices (+{bulkPercent}%)</span>
              </button>

              <button
                type="button"
                onClick={() => handleBulkPriceAdjust('decrease')}
                className="px-4 py-2 rounded-xl bg-emerald-900/60 hover:bg-emerald-800 text-emerald-200 border border-emerald-700/60 text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shadow"
              >
                <Percent className="w-3.5 h-3.5" />
                <span>Discount / Reduce (-{bulkPercent}%)</span>
              </button>
            </div>
          </div>

          {/* Coin Packages Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {coinPackages.map((pkg, index) => (
              <div 
                key={pkg.id} 
                className="bg-slate-900/90 border border-slate-800 hover:border-amber-500/50 rounded-3xl p-5 shadow-lg transition flex flex-col justify-between group"
              >
                <div>
                  <div className="flex items-center justify-between gap-2 mb-3">
                    <span className="text-xs font-mono font-bold text-slate-500">#{index + 1}</span>
                    {pkg.badge && (
                      <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40">
                        {pkg.badge}
                      </span>
                    )}
                  </div>

                  <div className="space-y-1">
                    <div className="text-2xl font-black text-amber-400 font-mono">
                      {pkg.coins.toLocaleString()} Coins
                    </div>
                    {pkg.bonusCoins > 0 && (
                      <div className="text-xs text-emerald-400 font-bold flex items-center gap-1">
                        <Sparkles className="w-3 h-3" />
                        <span>+{pkg.bonusCoins.toLocaleString()} Bonus Coins Free</span>
                      </div>
                    )}
                  </div>

                  {/* Pricing Matrix */}
                  <div className="mt-4 pt-4 border-t border-slate-800/80 space-y-2 text-xs">
                    <div className="flex justify-between items-center bg-slate-950/80 px-3 py-2 rounded-xl border border-slate-800">
                      <span className="text-slate-400 font-semibold">Pakistan (PKR):</span>
                      <span className="font-black text-white font-mono text-sm">
                        Rs. {pkg.pricePKR.toLocaleString()}
                      </span>
                    </div>
                    <div className="flex justify-between items-center bg-slate-950/80 px-3 py-2 rounded-xl border border-slate-800">
                      <span className="text-slate-400 font-semibold">International (USD):</span>
                      <span className="font-bold text-emerald-300 font-mono">
                        ${pkg.priceUSD.toFixed(2)}
                      </span>
                    </div>
                    <div className="flex justify-between items-center bg-slate-950/80 px-3 py-2 rounded-xl border border-slate-800">
                      <span className="text-slate-400 font-semibold">India (INR):</span>
                      <span className="font-bold text-cyan-300 font-mono">
                        ₹{pkg.priceINR.toLocaleString()}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2 mt-5 pt-3 border-t border-slate-800">
                  <button
                    type="button"
                    onClick={() => openEditPackageModal(pkg)}
                    className="flex-1 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <Edit3 className="w-3.5 h-3.5 text-amber-400" />
                    <span>Edit Price</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      if (coinPackages.length <= 1) {
                        alert('At least one coin package must remain.');
                        return;
                      }
                      deleteCoinPackage(pkg.id);
                      showNotification('Package removed.');
                    }}
                    className="p-2 rounded-xl hover:bg-rose-950/50 text-slate-500 hover:text-rose-400 border border-transparent hover:border-rose-900 transition cursor-pointer"
                    title="Delete package"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* SUB-TAB 2: WEBSITE BRANDING & IDENTITY */}
      {activeSubTab === 'branding' && (
        <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-xl">
          <form onSubmit={handleSaveBranding} className="space-y-6 max-w-3xl">
            <div>
              <h3 className="text-lg font-black text-white flex items-center gap-2 mb-1">
                <Globe className="w-5 h-5 text-purple-400" />
                Website Title & Identity Editor
              </h3>
              <p className="text-xs text-slate-400">
                Change the website name, official badge, announcement text, and header slogan.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  App / Website Name:
                </label>
                <input
                  type="text"
                  required
                  value={appName}
                  onChange={(e) => setAppName(e.target.value)}
                  placeholder="e.g. RB STAR Voice Chat Room"
                  className="w-full bg-slate-950 border border-slate-700 focus:border-purple-500 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  Official Badge Text:
                </label>
                <input
                  type="text"
                  value={officialBadge}
                  onChange={(e) => setOfficialBadge(e.target.value)}
                  placeholder="e.g. 👑 OFFICIAL or ⭐ VERIFIED"
                  className="w-full bg-slate-950 border border-slate-700 focus:border-purple-500 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1.5">
                Top Announcement Ticker (Shown across the whole website):
              </label>
              <input
                type="text"
                value={tickerText}
                onChange={(e) => setTickerText(e.target.value)}
                placeholder="e.g. Official Directory for Voice Chat App Admins, Verified Resellers, Agencies & CS"
                className="w-full bg-slate-950 border border-slate-700 focus:border-purple-500 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1.5">
                Hero Headline Description:
              </label>
              <textarea
                rows={2}
                value={heroDescription}
                onChange={(e) => setHeroDescription(e.target.value)}
                placeholder="e.g. Official Voice Chat Room In-App Showcase & Live Interface Preview"
                className="w-full bg-slate-950 border border-slate-700 focus:border-purple-500 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none resize-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1.5">
                App Logo Image URL / Path:
              </label>
              <input
                type="text"
                value={appLogo}
                onChange={(e) => setAppLogo(e.target.value)}
                placeholder="/assets/aistudio/... or https://..."
                className="w-full bg-slate-950 border border-slate-700 focus:border-purple-500 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none font-mono"
              />
            </div>

            <button
              type="submit"
              className="py-3 px-6 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white text-xs font-bold transition shadow-lg shadow-purple-950 flex items-center gap-2 cursor-pointer"
            >
              <Save className="w-4 h-4" />
              <span>Save & Apply Website Identity</span>
            </button>
          </form>
        </div>
      )}

      {/* SUB-TAB 3: SUPPORT & WHATSAPP CONTACTS */}
      {activeSubTab === 'contacts' && (
        <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-xl">
          <form onSubmit={handleSaveContacts} className="space-y-6 max-w-2xl">
            <div>
              <h3 className="text-lg font-black text-white flex items-center gap-2 mb-1">
                <Phone className="w-5 h-5 text-emerald-400" />
                Official Support Channels & Numbers
              </h3>
              <p className="text-xs text-slate-400">
                Update the official WhatsApp number, Telegram handle, and support email visible across the admin portal.
              </p>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1.5 flex items-center gap-1.5">
                <MessageCircle className="w-4 h-4 text-emerald-400" />
                Official WhatsApp Number:
              </label>
              <input
                type="text"
                value={supportWhatsApp}
                onChange={(e) => setSupportWhatsApp(e.target.value)}
                placeholder="+92 311 2486463"
                className="w-full bg-slate-950 border border-slate-700 focus:border-emerald-500 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1.5 flex items-center gap-1.5">
                <Globe className="w-4 h-4 text-cyan-400" />
                Official Telegram Channel / Handle:
              </label>
              <input
                type="text"
                value={supportTelegram}
                onChange={(e) => setSupportTelegram(e.target.value)}
                placeholder="@RBStarOfficial"
                className="w-full bg-slate-950 border border-slate-700 focus:border-cyan-500 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1.5 flex items-center gap-1.5">
                <Mail className="w-4 h-4 text-rose-400" />
                Official Support Email:
              </label>
              <input
                type="email"
                value={supportEmail}
                onChange={(e) => setSupportEmail(e.target.value)}
                placeholder="support@rbstarvoice.com"
                className="w-full bg-slate-950 border border-slate-700 focus:border-rose-500 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none"
              />
            </div>

            <button
              type="submit"
              className="py-3 px-6 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-bold transition shadow-lg shadow-emerald-950 flex items-center gap-2 cursor-pointer"
            >
              <Save className="w-4 h-4" />
              <span>Save Support Contacts</span>
            </button>
          </form>
        </div>
      )}

      {/* SUB-TAB 4: SHOWCASE SCREENSHOTS & MEDIA MANAGER */}
      {activeSubTab === 'screenshots' && (
        <div className="space-y-6">
          <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 sm:p-7 shadow-xl">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-6 pb-4 border-b border-slate-800">
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <ImageIcon className="w-4 h-4 text-pink-400" />
                  Showcase App Screenshots Manager ({screenshots.length} Screens)
                </h3>
                <p className="text-xs text-slate-400">
                  Screenshots automatically slide on the public landing screen and glide through the continuous marquee
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={resetAppScreenshots}
                  className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition cursor-pointer flex items-center gap-1.5"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Reset Default Media</span>
                </button>
                <button
                  type="button"
                  onClick={openAddScreenshotModal}
                  className="px-4 py-1.5 rounded-xl bg-pink-600 hover:bg-pink-500 text-white text-xs font-bold transition cursor-pointer flex items-center gap-1.5 shadow"
                >
                  <Plus className="w-4 h-4" />
                  <span>+ Add Screenshot</span>
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
              {screenshots.map((shot, idx) => (
                <div 
                  key={shot.id} 
                  className="bg-slate-950/80 border border-slate-800 hover:border-pink-500/50 rounded-2xl p-4 shadow-lg transition flex flex-col justify-between"
                >
                  <div>
                    <div className="h-44 w-full overflow-hidden rounded-xl bg-slate-900 mb-3 border border-slate-800">
                      <img 
                        src={shot.src} 
                        alt={shot.title} 
                        className="w-full h-full object-cover" 
                      />
                    </div>
                    <div className="flex items-center justify-between gap-1 mb-1">
                      <span className="text-[10px] font-bold text-amber-400 truncate">
                        {shot.badge}
                      </span>
                      <span className="text-[10px] text-slate-500 font-mono">#{idx + 1}</span>
                    </div>
                    <h4 className="text-xs font-bold text-white line-clamp-2">
                      {shot.title}
                    </h4>
                    <span className="text-[10px] text-slate-400 block mt-1">
                      Category: {shot.category}
                    </span>
                  </div>

                  <div className="flex items-center gap-2 mt-4 pt-3 border-t border-slate-800/80">
                    <button
                      type="button"
                      onClick={() => openEditScreenshotModal(shot)}
                      className="flex-1 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition flex items-center justify-center gap-1 cursor-pointer"
                    >
                      <Edit3 className="w-3 h-3 text-pink-400" />
                      <span>Edit</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        if (screenshots.length <= 1) {
                          alert('At least one screenshot is required for the showcase.');
                          return;
                        }
                        deleteAppScreenshot(shot.id);
                        showNotification('Screenshot removed.');
                      }}
                      className="p-1.5 rounded-lg hover:bg-rose-950/50 text-slate-500 hover:text-rose-400 transition cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* MODAL: ADD / EDIT COIN PACKAGE */}
      {isPackageModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fadeIn">
          <div className="bg-slate-900 border border-amber-500/50 rounded-3xl p-6 sm:p-7 max-w-lg w-full shadow-2xl relative space-y-5">
            <button
              onClick={() => setIsPackageModalOpen(false)}
              className="absolute top-4 right-4 p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>

            <div>
              <h3 className="text-lg font-black text-white flex items-center gap-2">
                <Coins className="w-5 h-5 text-amber-400" />
                <span>{editingPackageId ? 'Edit Coin Package Rates' : 'Create New Coin Package'}</span>
              </h3>
              <p className="text-xs text-slate-400">
                Set coin amounts, free bonus coins, and custom prices across PKR, USD, and INR.
              </p>
            </div>

            <form onSubmit={handleSavePackage} className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    Coins Amount <span className="text-rose-400">*</span>:
                  </label>
                  <input
                    type="number"
                    min="1"
                    required
                    value={pkgCoins}
                    onChange={(e) => setPkgCoins(Math.max(1, parseInt(e.target.value) || 0))}
                    className="w-full bg-slate-950 border border-slate-700 focus:border-amber-500 rounded-xl px-3.5 py-2 text-sm text-amber-300 font-mono font-bold focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    Bonus Coins Free:
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={pkgBonus}
                    onChange={(e) => setPkgBonus(Math.max(0, parseInt(e.target.value) || 0))}
                    className="w-full bg-slate-950 border border-slate-700 focus:border-amber-500 rounded-xl px-3.5 py-2 text-sm text-emerald-300 font-mono font-bold focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  Price in Pakistan PKR (Rs.) <span className="text-rose-400">*</span>:
                </label>
                <input
                  type="number"
                  min="1"
                  required
                  value={pkgPricePKR}
                  onChange={(e) => setPkgPricePKR(Math.max(1, parseInt(e.target.value) || 0))}
                  className="w-full bg-slate-950 border border-slate-700 focus:border-amber-500 rounded-xl px-3.5 py-2 text-sm text-white font-mono font-bold focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    Price in USD ($):
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    min="0.1"
                    required
                    value={pkgPriceUSD}
                    onChange={(e) => setPkgPriceUSD(Math.max(0.1, parseFloat(e.target.value) || 0.1))}
                    className="w-full bg-slate-950 border border-slate-700 focus:border-amber-500 rounded-xl px-3.5 py-2 text-sm text-white font-mono font-bold focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    Price in INR (₹):
                  </label>
                  <input
                    type="number"
                    min="1"
                    required
                    value={pkgPriceINR}
                    onChange={(e) => setPkgPriceINR(Math.max(1, parseInt(e.target.value) || 0))}
                    className="w-full bg-slate-950 border border-slate-700 focus:border-amber-500 rounded-xl px-3.5 py-2 text-sm text-white font-mono font-bold focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  Badge Label (e.g. Starter, Popular, VIP Choice, Crown Whale):
                </label>
                <input
                  type="text"
                  value={pkgBadge}
                  onChange={(e) => setPkgBadge(e.target.value)}
                  placeholder="e.g. VIP Choice 👑"
                  className="w-full bg-slate-950 border border-slate-700 focus:border-amber-500 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsPackageModalOpen(false)}
                  className="flex-1 py-2.5 rounded-xl border border-slate-700 text-slate-300 text-xs font-semibold hover:bg-slate-800 transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-black transition cursor-pointer shadow"
                >
                  {editingPackageId ? 'Save Changes' : 'Add Package'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: ADD / EDIT SCREENSHOT */}
      {isScreenshotModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fadeIn">
          <div className="bg-slate-900 border border-pink-500/50 rounded-3xl p-6 sm:p-7 max-w-lg w-full shadow-2xl relative space-y-5">
            <button
              onClick={() => setIsScreenshotModalOpen(false)}
              className="absolute top-4 right-4 p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>

            <div>
              <h3 className="text-lg font-black text-white flex items-center gap-2">
                <ImageIcon className="w-5 h-5 text-pink-400" />
                <span>{editingScreenshotId ? 'Edit Screenshot' : 'Add Showcase Screenshot'}</span>
              </h3>
              <p className="text-xs text-slate-400">
                Provide an image path or URL to showcase in the public slider and marquee.
              </p>
            </div>

            <form onSubmit={handleSaveScreenshot} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  Image Path / URL <span className="text-rose-400">*</span>:
                </label>
                <input
                  type="text"
                  required
                  value={screenSrc}
                  onChange={(e) => setScreenSrc(e.target.value)}
                  placeholder="/assets/aistudio/... or https://..."
                  className="w-full bg-slate-950 border border-slate-700 focus:border-pink-500 rounded-xl px-3.5 py-2 text-xs text-white font-mono focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  Screenshot Title <span className="text-rose-400">*</span>:
                </label>
                <input
                  type="text"
                  required
                  value={screenTitle}
                  onChange={(e) => setScreenTitle(e.target.value)}
                  placeholder="e.g. VIP Audio Room Stage & Live PK Battle"
                  className="w-full bg-slate-950 border border-slate-700 focus:border-pink-500 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    Category:
                  </label>
                  <input
                    type="text"
                    value={screenCategory}
                    onChange={(e) => setScreenCategory(e.target.value)}
                    placeholder="e.g. Mic Stage PK"
                    className="w-full bg-slate-950 border border-slate-700 focus:border-pink-500 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    Badge Title:
                  </label>
                  <input
                    type="text"
                    value={screenBadge}
                    onChange={(e) => setScreenBadge(e.target.value)}
                    placeholder="e.g. 👑 Official UI"
                    className="w-full bg-slate-950 border border-slate-700 focus:border-pink-500 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none"
                  />
                </div>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsScreenshotModalOpen(false)}
                  className="flex-1 py-2.5 rounded-xl border border-slate-700 text-slate-300 text-xs font-semibold hover:bg-slate-800 transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-pink-600 hover:bg-pink-500 text-white text-xs font-bold transition cursor-pointer shadow"
                >
                  {editingScreenshotId ? 'Save Changes' : 'Add Screenshot'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

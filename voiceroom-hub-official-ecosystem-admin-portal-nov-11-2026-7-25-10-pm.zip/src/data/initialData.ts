import { AdminUser, CoinReseller, VoiceRoom, Agency, BDManager, SupportTicket, CoinPackage, CoinTransaction, AppConnectionConfig, BannedUser, StaffApplication } from '../types';

export const INITIAL_MASTER_PASSWORD = 'admin'; // Owner password (can be changed to any custom password)

export const INITIAL_STAFF_APPLICATIONS: StaffApplication[] = [];

export const INITIAL_COIN_PACKAGES: CoinPackage[] = [
  { id: 'pkg-1', coins: 10000, bonusCoins: 500, pricePKR: 350, priceUSD: 1.25, priceINR: 105, badge: 'Starter' },
  { id: 'pkg-2', coins: 50000, bonusCoins: 3500, pricePKR: 1700, priceUSD: 6.10, priceINR: 510, badge: 'Popular' },
  { id: 'pkg-3', coins: 100000, bonusCoins: 10000, pricePKR: 3350, priceUSD: 11.99, priceINR: 999, badge: 'VIP Choice' },
  { id: 'pkg-4', coins: 500000, bonusCoins: 65000, pricePKR: 16500, priceUSD: 59.00, priceINR: 4900, badge: 'Mega Bundle' },
  { id: 'pkg-5', coins: 1000000, bonusCoins: 150000, pricePKR: 32500, priceUSD: 115.00, priceINR: 9600, badge: 'Whale Crown 👑' },
];

// No dummy staff - Only staff registered by the owner will appear here
export const INITIAL_ADMIN_USERS: AdminUser[] = [];

// No dummy banned users
export const INITIAL_BANNED_USERS: BannedUser[] = [];

// No dummy resellers - Only resellers registered by the owner will appear here
export const INITIAL_RESELLERS: CoinReseller[] = [];

// No dummy rooms
export const INITIAL_VOICE_ROOMS: VoiceRoom[] = [];

// No dummy agencies
export const INITIAL_AGENCIES: Agency[] = [];

// No dummy BDs
export const INITIAL_BDS: BDManager[] = [];

// No dummy tickets
export const INITIAL_TICKETS: SupportTicket[] = [];

// No dummy transactions
export const INITIAL_TRANSACTIONS: CoinTransaction[] = [];

export const INITIAL_APP_CONFIG: AppConnectionConfig = {
  appName: 'RB STAR Voice Chat Room',
  appLogo: '/assets/aistudio/WhatsApp_Image_2026-11-10_at_8.07.38_AM_9cc28500.jpeg',
  appPackageId: 'com.rbstar.voicechat.room',
  webhookUrl: '',
  apiKey: '',
  syncIntervalSeconds: 30,
  serverStatus: 'connected',
  lastPingMs: 20,
  lastSyncedAt: 'Live',
  totalApiRequests: 0
};

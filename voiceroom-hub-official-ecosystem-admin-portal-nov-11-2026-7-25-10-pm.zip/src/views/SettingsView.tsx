import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  Key, 
  Lock, 
  Unlock, 
  ShieldCheck, 
  CheckCircle2, 
  AlertCircle, 
  Settings, 
  Globe, 
  Smartphone, 
  Trash2,
  Sparkles
} from 'lucide-react';

interface SettingsViewProps {
  onOpenPasswordModal: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({ onOpenPasswordModal }) => {
  const { 
    masterPassword, 
    changeMasterPassword, 
    isUnlocked, 
    lockPortal, 
    unlockPortal,
    appConfig,
    updateAppConfig,
    isRomanUrdu,
    setIsRomanUrdu,
    resetAllData
  } = useApp();

  const [newPwd, setNewPwd] = useState('');
  const [confirmPwd, setConfirmPwd] = useState('');
  const [appNameInput, setAppNameInput] = useState(appConfig.appName);
  const [msg, setMsg] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  const handleSavePassword = (e: React.FormEvent) => {
    e.preventDefault();
    setMsg('');
    setErrorMsg('');

    if (newPwd.length < 3) {
      setErrorMsg(isRomanUrdu ? 'Password kam az kam 3 characters ka hona chiya.' : 'Password must be at least 3 characters.');
      return;
    }
    if (newPwd !== confirmPwd) {
      setErrorMsg(isRomanUrdu ? 'Password match nahi kar rahe!' : 'Passwords do not match!');
      return;
    }

    const ok = changeMasterPassword(newPwd);
    if (ok) {
      setMsg(isRomanUrdu ? 'Mubarak ho! Aap ka custom password save ho chuka ha.' : 'Success! Your custom password has been saved.');
      setNewPwd('');
      setConfirmPwd('');
    }
  };

  const handleSaveAppName = (e: React.FormEvent) => {
    e.preventDefault();
    if (!appNameInput.trim()) return;
    updateAppConfig({ appName: appNameInput.trim() });
    setMsg(isRomanUrdu ? 'App ka naam update ho chuka ha!' : 'App name updated successfully!');
  };

  return (
    <div className="space-y-6 animate-fadeIn pb-12 max-w-4xl mx-auto">
      {/* Header */}
      <div className="bg-gradient-to-r from-purple-950 via-slate-900 to-indigo-950 border border-purple-800/50 rounded-3xl p-6 md:p-8 shadow-2xl flex items-center justify-between">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="px-3 py-1 rounded-full bg-purple-500/20 text-purple-300 border border-purple-500/40 text-xs font-black uppercase flex items-center gap-1.5">
              <Settings className="w-3.5 h-3.5" />
              <span>RB STAR SECURITY & PASSWORDS</span>
            </span>
          </div>
          <h1 className="text-2xl md:text-3xl font-black text-white mt-1">
            RB STAR Voice Chat Room — Settings
          </h1>
          <p className="text-xs text-slate-300">
            Configure your custom master access code and RB STAR identity
          </p>
        </div>

        <div className="shrink-0">
          <img 
            src="/assets/aistudio/WhatsApp_Image_2026-11-10_at_8.07.38_AM_9cc28500.jpeg" 
            alt="RB STAR" 
            className="w-16 h-16 rounded-2xl object-cover ring-2 ring-amber-400 shadow-xl shadow-purple-950" 
          />
        </div>
      </div>

      {/* Success / Error notification */}
      {msg && (
        <div className="p-4 rounded-2xl bg-emerald-950/70 border border-emerald-800 text-emerald-300 text-xs flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
          <span>{msg}</span>
        </div>
      )}

      {errorMsg && (
        <div className="p-4 rounded-2xl bg-rose-950/70 border border-rose-800 text-rose-300 text-xs flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
          <span>{errorMsg}</span>
        </div>
      )}

      {/* 1. Custom Master Password Card */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 space-y-5">
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div>
            <h3 className="font-bold text-white text-base flex items-center gap-2">
              <Key className="w-4 h-4 text-amber-400" />
              <span>{isRomanUrdu ? 'Apni Marzi Ka Owner Password' : 'Custom Owner Master Password'}</span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              {isRomanUrdu ? 'Yeh password save hone ke baad sirf aap controls chala sakein gay' : 'Set your confidential owner passphrase to lock access from public users'}
            </p>
          </div>

          <div className="flex items-center gap-2">
            <span className={`text-[10px] font-mono px-2.5 py-1 rounded-full border ${
              isUnlocked ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40' : 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
            }`}>
              {isUnlocked ? 'PORTAL UNLOCKED' : 'LOCKED'}
            </span>
          </div>
        </div>

        <form onSubmit={handleSavePassword} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                {isRomanUrdu ? 'Naya Password Likhein:' : 'New Custom Password:'}
              </label>
              <input
                type="text"
                required
                value={newPwd}
                onChange={(e) => setNewPwd(e.target.value)}
                placeholder="e.g. AdminRB@2026"
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none focus:border-amber-500"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                {isRomanUrdu ? 'Password Dobara Likhein (Confirm):' : 'Confirm New Password:'}
              </label>
              <input
                type="password"
                required
                value={confirmPwd}
                onChange={(e) => setConfirmPwd(e.target.value)}
                placeholder="Repeat password"
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none focus:border-amber-500"
              />
            </div>
          </div>

          <div className="flex justify-between items-center pt-2">
            <div className="text-[11px] text-slate-500">
              💡 Current active password length: <strong className="text-amber-400 font-mono">{masterPassword.length} characters</strong>
            </div>

            <button
              type="submit"
              className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-500 hover:to-amber-600 text-white text-xs font-bold transition shadow-lg shadow-amber-950 cursor-pointer"
            >
              {isRomanUrdu ? 'Naya Password Save Karein' : 'Save Password'}
            </button>
          </div>
        </form>
      </div>

      {/* 2. App Name & Branding */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 space-y-4">
        <h3 className="font-bold text-white text-base flex items-center gap-2">
          <Smartphone className="w-4 h-4 text-purple-400" />
          <span>{isRomanUrdu ? 'App Branding & Name' : 'App Identity & Title'}</span>
        </h3>

        <form onSubmit={handleSaveAppName} className="flex gap-3">
          <input
            type="text"
            value={appNameInput}
            onChange={(e) => setAppNameInput(e.target.value)}
            className="flex-1 bg-slate-950 border border-slate-700 rounded-xl px-4 py-2 text-xs text-white focus:outline-none focus:border-purple-500"
          />
          <button
            type="submit"
            className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold transition cursor-pointer"
          >
            {isRomanUrdu ? 'Naam Update Karein' : 'Update Name'}
          </button>
        </form>
      </div>

      {/* 3. Language & UI Preference */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="font-bold text-white text-sm flex items-center gap-2">
              <Globe className="w-4 h-4 text-cyan-400" />
              <span>Language Setting</span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Portal interface is configured in English
            </p>
          </div>

          <span className="px-3.5 py-1.5 rounded-xl bg-purple-900/40 text-purple-300 border border-purple-500/30 text-xs font-bold">
            English (Active)
          </span>
        </div>
      </div>

      {/* 4. 100% Free Publishing & Zero-Cost Hosting Guide */}
      <div className="bg-gradient-to-r from-emerald-950/60 via-slate-900 to-indigo-950/60 border border-emerald-500/40 rounded-3xl p-6 space-y-4">
        <div className="flex items-center gap-2 text-emerald-400">
          <ShieldCheck className="w-5 h-5" />
          <h3 className="font-bold text-white text-base">
            {isRomanUrdu ? '100% Free Website Publishing Guide' : '100% Free & Open Deployment'}
          </h3>
        </div>

        <p className="text-xs text-slate-300 leading-relaxed">
          {isRomanUrdu 
            ? 'Yeh website mukammal tor par 100% FREE hai! Is me koi paid software, paid database ya monthly charges nahi hain. Aap is website ko kisi bhi platform par bilkul muft (free) publish kar sakte hain:'
            : 'This web portal is 100% free and client-driven. There are zero paid subscriptions, paid databases, or third-party fees.'}
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
          <div className="p-3.5 bg-slate-950/80 rounded-2xl border border-slate-800 space-y-1">
            <span className="text-emerald-400 font-bold text-xs">Vercel (Free)</span>
            <p className="text-[11px] text-slate-400">Connect GitHub repo for instant 1-click free production deployment.</p>
          </div>
          <div className="p-3.5 bg-slate-950/80 rounded-2xl border border-slate-800 space-y-1">
            <span className="text-emerald-400 font-bold text-xs">Netlify (Free)</span>
            <p className="text-[11px] text-slate-400">Drag & drop the dist build folder for immediate free hosting.</p>
          </div>
          <div className="p-3.5 bg-slate-950/80 rounded-2xl border border-slate-800 space-y-1">
            <span className="text-emerald-400 font-bold text-xs">Cloudflare Pages</span>
            <p className="text-[11px] text-slate-400">Deploy with global CDN, unlimited bandwidth and free SSL certificates.</p>
          </div>
        </div>

        <div className="p-3 bg-slate-950 rounded-xl border border-emerald-900/40 text-[11px] font-mono text-emerald-300">
          Build Command: <strong className="text-white">npm run build</strong> &rarr; Output Directory: <strong className="text-white">dist</strong>
        </div>
      </div>
    </div>
  );
};

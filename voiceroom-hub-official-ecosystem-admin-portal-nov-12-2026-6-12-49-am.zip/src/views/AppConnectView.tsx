import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  Radio, 
  Key, 
  RefreshCw, 
  CheckCircle2, 
  Copy, 
  Terminal, 
  Download, 
  Upload, 
  Sparkles, 
  ShieldCheck, 
  Layers, 
  Code2, 
  Check,
  Server
} from 'lucide-react';

export const AppConnectView: React.FC = () => {
  const { 
    appConfig, 
    updateAppConfig, 
    testAppPing, 
    exportDatabaseJSON, 
    importDatabaseJSON, 
    resetAllData,
    isRomanUrdu 
  } = useApp();

  const [copiedKey, setCopiedKey] = useState(false);
  const [copiedUrl, setCopiedUrl] = useState(false);
  const [pingTesting, setPingTesting] = useState(false);
  const [pingResult, setPingResult] = useState<number | null>(appConfig.lastPingMs);
  const [activeTabCode, setActiveTabCode] = useState<'kotlin' | 'swift' | 'nodejs'>('kotlin');

  const handleCopyKey = () => {
    navigator.clipboard.writeText(appConfig.apiKey);
    setCopiedKey(true);
    setTimeout(() => setCopiedKey(false), 2000);
  };

  const handleCopyUrl = () => {
    navigator.clipboard.writeText(appConfig.webhookUrl);
    setCopiedUrl(true);
    setTimeout(() => setCopiedUrl(false), 2000);
  };

  const handlePingTest = async () => {
    setPingTesting(true);
    try {
      const ms = await testAppPing();
      setPingResult(ms);
    } finally {
      setPingTesting(false);
    }
  };

  const handleFileImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      const success = importDatabaseJSON(content);
      if (success) {
        alert(isRomanUrdu ? 'Kamiyabi! Database JSON import ho chuki ha.' : 'Success! Database JSON successfully restored.');
      } else {
        alert(isRomanUrdu ? 'Ghalat JSON file format!' : 'Invalid JSON file format!');
      }
    };
    reader.readAsText(file);
  };

  const codeSnippets = {
    kotlin: `// Android (Kotlin) Voice Room Integration
// Call this whenever a user gifts coins or gets muted
val syncPayload = JSONObject().apply {
    put("appId", currentUser.appId)
    put("roomNumber", activeRoom.number)
    put("eventType", "ROOM_MIC_ACTIVITY")
    put("apiKey", "${appConfig.apiKey}")
}

Fuel.post("${appConfig.webhookUrl}")
    .jsonBody(syncPayload.toString())
    .responseString { _, _, result ->
        Log.d("VoiceRoom", "Sync status: \${result.get()}")
    }`,

    swift: `// iOS (Swift) Voice Room App Integration
let payload: [String: Any] = [
    "appId": currentUser.id,
    "roomNumber": currentRoom.roomNumber,
    "eventType": "COIN_PURCHASE_VERIFY",
    "apiKey": "${appConfig.apiKey}"
]

var request = URLRequest(url: URL(string: "${appConfig.webhookUrl}")!)
request.httpMethod = "POST"
request.httpBody = try? JSONSerialization.data(withJSONObject: payload)
URLSession.shared.dataTask(with: request).resume()`,

    nodejs: `// Node.js / Express WebRTC Voice Gateway Server
const axios = require('axios');

async function syncWithPortal(eventType, data) {
  await axios.post('${appConfig.webhookUrl}', {
    apiKey: '${appConfig.apiKey}',
    eventType: eventType,
    timestamp: Date.now(),
    payload: data
  });
}`
  };

  return (
    <div className="space-y-6 animate-fadeIn pb-12">
      {/* Banner */}
      <div className="bg-gradient-to-r from-cyan-950 via-slate-900 to-indigo-950 border border-cyan-800/50 rounded-3xl p-6 md:p-8 shadow-2xl flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-3 py-1 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 text-xs font-black uppercase flex items-center gap-1.5">
              <Radio className="w-3.5 h-3.5 animate-pulse" />
              <span>VOICE APP SERVER BRIDGE & API</span>
            </span>
            <span className="text-xs text-emerald-400 font-mono">
              ● Server Connected ({pingResult || 28}ms)
            </span>
          </div>

          <h1 className="text-2xl md:text-3xl font-black text-white mt-2">
            Voice App Connection & Webhook Gateway
          </h1>
          <p className="text-xs md:text-sm text-slate-300 max-w-2xl mt-1 leading-relaxed">
            Link your mobile audio chat room application with this website via Webhooks, API keys, and real-time event streaming.
          </p>
        </div>

        <button
          onClick={handlePingTest}
          disabled={pingTesting}
          className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-600 to-teal-600 hover:from-cyan-500 hover:to-teal-500 text-white text-xs font-bold transition flex items-center gap-2 shadow-lg shadow-cyan-950 shrink-0 cursor-pointer disabled:opacity-50"
        >
          <RefreshCw className={`w-4 h-4 ${pingTesting ? 'animate-spin' : ''}`} />
          <span>{pingTesting ? 'Testing Latency...' : 'Test Connection'}</span>
        </button>
      </div>

      {/* Connection Credentials Card */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 space-y-5">
        <h3 className="font-bold text-white text-base flex items-center gap-2">
          <Server className="w-5 h-5 text-cyan-400" />
          <span>API Keys & Endpoints</span>
        </h3>

        <div className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-slate-400 mb-1">
              App Webhook Sync Endpoint:
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                readOnly
                value={appConfig.webhookUrl}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-xs text-white font-mono focus:outline-none"
              />
              <button
                onClick={handleCopyUrl}
                className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer"
              >
                {copiedUrl ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                <span>{copiedUrl ? 'Copied' : 'Copy'}</span>
              </button>
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-400 mb-1">
              Secret API Authorization Key:
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                readOnly
                value={appConfig.apiKey}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-xs text-amber-300 font-mono focus:outline-none"
              />
              <button
                onClick={handleCopyKey}
                className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer"
              >
                {copiedKey ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                <span>{copiedKey ? 'Copied' : 'Copy'}</span>
              </button>
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 pt-2 text-xs">
            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
              <span className="text-slate-500 block text-[10px]">App Package ID:</span>
              <span className="text-white font-mono font-bold">{appConfig.appPackageId}</span>
            </div>
            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
              <span className="text-slate-500 block text-[10px]">Server Latency:</span>
              <span className="text-emerald-400 font-mono font-bold">{pingResult} ms</span>
            </div>
            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
              <span className="text-slate-500 block text-[10px]">Total Synced Requests:</span>
              <span className="text-purple-300 font-mono font-bold">{appConfig.totalApiRequests.toLocaleString()}</span>
            </div>
            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
              <span className="text-slate-500 block text-[10px]">Sync Interval:</span>
              <span className="text-slate-300 font-mono font-bold">Every {appConfig.syncIntervalSeconds}s</span>
            </div>
          </div>
        </div>
      </div>

      {/* Code Snippets for Developers */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="font-bold text-white text-base flex items-center gap-2">
              <Code2 className="w-5 h-5 text-indigo-400" />
              <span>App Developer Integration Guide</span>
            </h3>
            <p className="text-xs text-slate-400">
              Quickly integrate your mobile app with this portal
            </p>
          </div>

          <div className="flex gap-1.5 p-1 bg-slate-950 rounded-xl border border-slate-800 text-xs">
            {(['kotlin', 'swift', 'nodejs'] as const).map(tab => (
              <button
                key={tab}
                onClick={() => setActiveTabCode(tab)}
                className={`px-3 py-1 rounded-lg font-mono font-bold capitalize transition cursor-pointer ${
                  activeTabCode === tab ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                {tab === 'kotlin' ? 'Android (Kotlin)' : tab === 'swift' ? 'iOS (Swift)' : 'Node.js'}
              </button>
            ))}
          </div>
        </div>

        <div className="relative">
          <pre className="p-4 bg-slate-950 border border-slate-800 rounded-2xl overflow-x-auto text-xs font-mono text-cyan-300/90 leading-relaxed">
            {codeSnippets[activeTabCode]}
          </pre>
        </div>
      </div>

      {/* Free Database Backup & Restore */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 space-y-4">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-purple-500/20 border border-purple-500/30 flex items-center justify-center text-purple-400">
            <Layers className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-white text-base">
              Database Backup & JSON Storage
            </h3>
            <p className="text-xs text-slate-400">
              Zero cloud hosting charges. All data safely saved in client storage with 1-click JSON backup.
            </p>
          </div>
        </div>

        <div className="flex flex-wrap gap-3 pt-2">
          <button
            onClick={exportDatabaseJSON}
            className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold transition flex items-center gap-2 border border-slate-700 cursor-pointer"
          >
            <Download className="w-4 h-4 text-emerald-400" />
            <span>Export Database JSON</span>
          </button>

          <label className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold transition flex items-center gap-2 border border-slate-700 cursor-pointer">
            <Upload className="w-4 h-4 text-amber-400" />
            <span>Import Database JSON</span>
            <input type="file" accept=".json" onChange={handleFileImport} className="hidden" />
          </label>

          <button
            onClick={() => {
              if (confirm('Reset to default initial data?')) {
                resetAllData();
              }
            }}
            className="px-4 py-2.5 rounded-xl bg-rose-950/40 hover:bg-rose-950/70 text-rose-300 text-xs font-semibold transition border border-rose-800/50 cursor-pointer ml-auto"
          >
            Reset Database
          </button>
        </div>
      </div>
    </div>
  );
};
